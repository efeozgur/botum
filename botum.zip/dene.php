<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="css/stilim.css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" />
</head>
<body>
	<div class="cerceve">
		<h3 style="text-align:center">Tahminlerimizi sizlerle paylaşıyoruz </h3>
		<center><img width="200" height="200" src="img/para.png" alt="" /></center>
		<p style="text-align:center; font-size:14px"> Şimdi tablomuzdaki alanları inceleyelim </p>
		<p>1. (Tarih) Maçın tarihini gösterir</p>
		<p>2. (Lig) Maçın hangi ligde oynandığını gösterir</p>
		<p>3. (Kod) Maçın kodunu gösterir</p>
		<p>4. (Maç) Maçın hangi takımlar arasında oynandığını gösterir</p>
		<p>5. (Kategori) Maç hakkında yapılacak tahminin kategorisini gösterir</p>
		<p>6. (Tahmin Tipi) Maç hakkında yapılacak tahminin tipini gösterir</p>
		<p>7. (Oran Tipi) Maç hakkında yapılacak tahminin oran tipini gösterir</p>
		<p>8. (Oran) Maç hakkında yapılacak tahminin oranını gösterir</p>
		<p>9. (Olasılık) Maç hakkında yapılacak tahminin tutma olasılığını gösterir</p>
	</div>
	<div class="cerceve2">
		<h3 style="text-align:center" >Nasıl kazanırım ?</h3>
		<p>dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır.</p>
	</div>
</body>
</html>